const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB({
  region: "us-east-1",
  apiVersion: "2012-08-10",
});

exports.handler = async (event, context, callback) => {
  const params = {
    Key: {
      Book_id: {
        S: event.Book_id,
      },
    },
    ExpressionAttributeNames: {
      '#T': 'Title',
      '#A': 'Author',
      '#P': 'Publication_date',
      '#L': 'Language',
    },
    ExpressionAttributeValues: {
      ':t': {
        S: event.newTitle,
      },
      ':a': {
        S: event.newAuthor,
      },
      ':p': {
        S: event.newDate,
      },
      ':l': {
        S: event.newLanguage,
      }
    },
    UpdateExpression: 'SET #T = :t, #A = :a, #P = :p, #L = :l',
    TableName: "KumoTable",
  };
  
  try {
    await dynamodb.updateItem(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ result: 'success' }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ result: 'failure' }),
    };
  }
};