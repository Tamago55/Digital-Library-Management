const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB({
  region: "us-east-1",
  apiVersion: "2012-08-10",
});

exports.handler = async (event, content, callback) => {
  const params = {
    Item: {
      Book_id: {
        S: Math.random().toString(32).substring(2),
      },
      Publication_date: {
        S: event.date,
      },
      Title: {
        S: event.title,
      },
      Author: {
        S: event.author,
      },
      Language: {
        S: event.booklanguage,
      },

    },
    TableName: "KumoTable",
  };
  await dynamodb.putItem(params).promise();
  return {
    statusCode: 200,
    body: JSON.stringify({ result: 'success' }),
  };
};