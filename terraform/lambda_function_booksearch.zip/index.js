const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const keyword = event.keyword;

    const params = {
        TableName: 'KumoTable',
        FilterExpression: 'contains(#bookId, :keyword) OR contains(#title, :keyword) OR contains(#author, :keyword) OR contains(#bookDate, :keyword) OR contains(#language, :keyword)',
        ExpressionAttributeNames: { 
            '#bookId': 'Book_id',
            '#title': 'Title',
            '#author': 'Author',
            '#bookDate': 'Book_date',
            '#language': 'Language'
        },
        ExpressionAttributeValues: { ':keyword': keyword }
    };
  
    const response = await dynamodb.scan(params).promise();

    return {
        statusCode: 200,
        body: JSON.stringify(response.Items),
    };
};